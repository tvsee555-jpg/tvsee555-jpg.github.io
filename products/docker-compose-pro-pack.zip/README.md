# Docker Compose Pro Pack

Stop spending 2 hours setting up PostgreSQL, Redis, Nginx, and Mailpit for every new project. Copy a folder, run `docker compose up`, done.

## Included Stacks

| Stack | Folder | Port | Services |
|---|---|---|---|
| **Python / FastAPI** | `python-fastapi/` | :8000 | FastAPI, PostgreSQL 16, Redis 7, Nginx, Mailpit |
| **Node.js / Express** | `node-express/` | :3000 | Express, PostgreSQL 16, Redis 7, Nginx, Mailpit |
| **Go** | `go-server/` | :8080 | Go (chi), PostgreSQL 16, Redis 7, Nginx, Mailpit |
| **Rust** | `rust-server/` | :8080 | Rust (Axum), PostgreSQL 16, Redis 7, Nginx, Mailpit |
| **Next.js Fullstack** | `nextjs-fullstack/` | :3000 | Next.js, PostgreSQL 16, Redis 7, Nginx, Mailpit |

Every stack includes:
- **PostgreSQL 16** — With named volume for data persistence and health checks
- **Redis 7** — With health check
- **Nginx** — Reverse proxy with proper headers and static file serving
- **Mailpit** — SMTP server for dev email testing (web UI at :8025)
- **Multi-stage Dockerfile** — Optimized for tiny production images
- **Makefile** — `make up`, `make down`, `make logs`, `make test`, `make prod`

## Quick Start

```bash
# Pick your stack
cd docker-compose-pro-pack/python-fastapi

# Copy and edit environment
cp .env.example .env

# Start everything
docker compose up -d
```

## Port Allocation

All stacks use different local ports so you can run multiple simultaneously:

| Service | Python | Node | Go | Rust | Next.js |
|---|---|---|---|---|---|
| App | 8000 | 3000 | 8080 | 8080 | 3000 |
| Nginx | 8001 | 3001 | 8081 | 8081 | 3001 |
| PostgreSQL | 5432 | 5433 | 5434 | 5435 | 5436 |
| Redis | 6379 | 6380 | 6381 | 6382 | 6383 |
| Mailpit Web | 8025 | 8026 | 8027 | 8028 | 8029 |
| Mailpit SMTP | 1025 | 1026 | 1027 | 1028 | 1029 |

## Architecture

```
┌─────────────┐     ┌──────────┐     ┌──────────────┐
│   Nginx     │────▶│   App    │────▶│  PostgreSQL  │
│  (reverse   │     │  (code)  │     │   (data)     │
│   proxy)    │     │          │     └──────────────┘
└─────────────┘     │          │     ┌──────────────┐
                    │          │────▶│    Redis     │
                    │          │     │   (cache)    │
                    └──────────┘     └──────────────┘
                                     ┌──────────────┐
                                     │   Mailpit    │
                                     │  (email dev) │
                                     └──────────────┘
```

## Common Commands

```bash
docker compose up -d        # Start all services in background
docker compose down         # Stop all services
docker compose logs -f api  # Follow API logs
docker compose exec api sh  # Shell into API container
make test                   # Run tests
make prod                   # Build for production (no dev tools)
```

## Requirements
- Docker Engine 24+
- Docker Compose v2+

## License
MIT — use in personal and commercial projects.
