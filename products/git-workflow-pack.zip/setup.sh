#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'
BOLD='\033[1m'

uninstall_mode=false
if [ "${1:-}" = "--uninstall" ] || [ "${1:-}" = "-u" ]; then
    uninstall_mode=true
fi

echo -e "${BLUE}╔══════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     Git Workflow Pack — Setup         ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════╝${NC}"
echo ""

if $uninstall_mode; then
    echo "Uninstalling Git Workflow Pack..."
    echo ""

    # Remove aliases from global gitconfig
    if grep -q '# Git Workflow Pack' ~/.gitconfig 2>/dev/null; then
        sed -i '/# Git Workflow Pack/,/# End Git Workflow Pack/d' ~/.gitconfig
        echo -e "${GREEN}✓${NC} Aliases removed from ~/.gitconfig"
    fi

    # Remove hooks
    HOOKS_DIR=$(git rev-parse --git-dir 2>/dev/null || echo "")
    if [ -n "$HOOKS_DIR" ] && [ -L "$HOOKS_DIR/hooks/pre-commit" ]; then
        rm -f "$HOOKS_DIR/hooks/pre-commit" \
              "$HOOKS_DIR/hooks/commit-msg" \
              "$HOOKS_DIR/hooks/pre-push" \
              "$HOOKS_DIR/hooks/prepare-commit-msg"
        echo -e "${GREEN}✓${NC} Git hooks removed"
    fi

    echo ""
    echo -e "${GREEN}✓ Uninstall complete${NC}"
    exit 0
fi

# ── Install Git Aliases ──────────────────────────────
echo "1. Installing Git aliases..."
CONFIG_FILE="$SCRIPT_DIR/.gitconfig"
if [ -f "$CONFIG_FILE" ]; then
    # Create a backup
    if [ -f ~/.gitconfig ]; then
        cp ~/.gitconfig ~/.gitconfig.bak.$(date +%Y%m%d_%H%M%S)
        echo "   Backed up existing ~/.gitconfig"
    fi

    # Extract only the [alias] section and append
    echo "" >> ~/.gitconfig
    echo "# Git Workflow Pack" >> ~/.gitconfig
    echo "# Installed: $(date)" >> ~/.gitconfig
    sed -n '/^\[alias\]/,/^\[/p' "$CONFIG_FILE" | sed '/^\[/d' >> ~/.gitconfig 2>/dev/null || true
    echo "# End Git Workflow Pack" >> ~/.gitconfig
    echo -e "${GREEN}✓${NC} Aliases installed to ~/.gitconfig"
else
    echo -e "${RED}✗${NC} Missing .gitconfig"
fi

# ── Install Git Hooks ────────────────────────────────
echo ""
echo "2. Installing Git hooks..."
HOOKS_SRC="$SCRIPT_DIR/.githooks"
if [ -d "$HOOKS_SRC" ]; then
    GIT_DIR=$(git rev-parse --git-dir 2>/dev/null || echo "")
    if [ -z "$GIT_DIR" ]; then
        echo -e "${YELLOW}⚠ Not a git repository. Skip hook installation.${NC}"
        echo "   Run 'git init' first, then re-run setup.sh"
    else
        for hook in pre-commit commit-msg pre-push prepare-commit-msg; do
            if [ -f "$HOOKS_SRC/$hook" ]; then
                cp "$HOOKS_SRC/$hook" "$GIT_DIR/hooks/$hook"
                chmod +x "$GIT_DIR/hooks/$hook"
                echo -e "${GREEN}✓${NC} Installed $hook hook"
            fi
        done
        echo ""
        echo "   To skip hooks temporarily: git commit --no-verify"
        echo "   To skip push hooks: git push --no-verify"
    fi
else
    echo -e "${RED}✗${NC} Missing .githooks/ directory"
fi

# ── Print Alias Summary ─────────────────────────────
echo ""
echo -e "${BOLD}Alias Reference${NC}"
echo "  ${BOLD}Status:${NC}  gst (status), glg (log graph), gdf (diff)"
echo "  ${BOLD}Branch:${NC}  gco (checkout), cob (checkout -b), brd (delete branch)"
echo "  ${BOLD}Commit:${NC}  cia (amend), fixup (fixup commit), undo (reset soft)"
echo "  ${BOLD}Sync:${NC}    up (fetch+pull), pl (pull), ps (push), psf (push --force-with-lease)"
echo "  ${BOLD}Rebase:${NC}  rb (rebase), rbi (rebase -i), rbc (continue)"
echo "  ${BOLD}Stash:${NC}   sh (stash), shp (pop), shl (list)"
echo "  ${BOLD}Clean:${NC}   cleanup (delete merged branches), nuke (reset+clean)"
echo "  ${BOLD}List:${NC}    alias (show all aliases)"
echo ""

echo -e "${GREEN}✓ Setup complete!${NC}"
echo ""
echo "To uninstall: bash setup.sh --uninstall"
echo "To see all aliases: git alias"
