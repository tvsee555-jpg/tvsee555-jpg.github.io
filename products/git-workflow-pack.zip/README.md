# Git Workflow Pack

Stop typing the same 5 commands wrong and forgetting how to set up hooks. Git is powerful — these configs make it actually pleasant.

## What's Included

### 65+ Git Aliases
Organized by category in a ready-to-use `.gitconfig`:

- **Status** — `gst` (status), `glg` (pretty log graph), `gdf` (diff)
- **Branch** — `gco` (checkout), `cob` (checkout -b), `brd` (delete), `cleanup` (delete merged)
- **Commit** — `cia` (amend), `fixup` (fixup commit), `undo` (reset soft), `redraft`
- **Sync** — `up` (fetch all + pull), `pl` (pull --rebase), `psf` (force-with-lease)
- **Rebase** — `rb`, `rbi` (interactive), `rbc` (continue), `rba` (abort)
- **Stash** — `sh`, `shp` (pop), `shl` (list), `shs` (show)
- **Search** — `find` (file search), `grep-log`, `file-history`, `my` (my commits)
- **Utility** — `alias` (show all), `today`/`yesterday`, `nuke` (reset+clean)

### 4 Git Hooks

| Hook | What It Does |
|---|---|
| `pre-commit` | Blocks debugger statements, merge conflicts, large files. Warns about TODOs/FIXMEs. |
| `commit-msg` | Enforces conventional commit format. Validates first line length (72 chars). |
| `pre-push` | Validates branch naming. Runs tests if available. |
| `prepare-commit-msg` | Auto-prepends conventional commit prefix from branch name. |

### Documentation

- `conventional-commits.md` — Complete cheat sheet with all types, examples, and anti-patterns
- `branch-naming.md` — Branch naming conventions with `feature/`, `fix/`, `chore/` prefixes

## Quick Start

```bash
# Clone or download the pack
cd git-workflow-pack

# One-command setup
bash setup.sh
```

The setup script will:
1. Append all aliases to your global `~/.gitconfig`
2. Install hooks in your current repository
3. Print a summary of available aliases

To uninstall: `bash setup.sh --uninstall`

## Requirements
- Git 2.30+
- Bash 4+

## License
MIT — use in personal and commercial projects.
