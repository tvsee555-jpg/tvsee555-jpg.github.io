# Branch Naming Convention

## Format

```
type/description
```

Lowercase only. Use hyphens to separate words in the description.

## Types

| Prefix     | When to Use                                   | Example                            |
|------------|-----------------------------------------------|------------------------------------|
| `feature/` | New features and improvements                 | `feature/user-profile-page`        |
| `fix/`     | Bug fixes                                     | `fix/login-redirect-loop`          |
| `chore/`   | Maintenance, dependency updates, tooling       | `chore/upgrade-node-to-20`         |
| `hotfix/`  | Urgent production fixes (skip CI for speed)   | `hotfix/payment-processing-error`  |
| `release/` | Release preparation                           | `release/v2.1.0`                   |
| `docs/`    | Documentation-only changes                    | `docs/api-authentication-guide`    |

## Examples

```
feature/oauth-login
feature/dark-mode-toggle
fix/null-pointer-in-profile
fix/cart-total-calculation
chore/update-docker-compose
chore/add-eslint-config
hotfix/ssl-cert-renewal
hotfix/database-connection-pool
release/v2.1.0
docs/deployment-guide
```

## Why This Matters

1. **CI/CD automation** — Triggers specific build/test pipelines per type
2. **Automatic changelogs** — Branch types map to conventional commits
3. **Code review clarity** — Reviewers know the intent before reading code
4. **Clean history** — Branch types make git log --graph easier to parse

## Pre-push Hook

The included `pre-push` hook validates branch naming automatically.
If your branch doesn't follow the convention, the push will be rejected with instructions.
