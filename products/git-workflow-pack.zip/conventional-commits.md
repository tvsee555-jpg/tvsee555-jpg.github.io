# Conventional Commits Cheat Sheet

A standardized format for commit messages that enables automatic changelog generation, semantic versioning, and clearer collaboration.

## Format

```
type(scope): description

[optional body]

[optional footer]
```

## Allowed Types

| Type       | When to Use                                           | Example                                          |
|------------|-------------------------------------------------------|--------------------------------------------------|
| `feat`     | A new feature for the user                            | `feat(auth): add Google OAuth login button`      |
| `fix`      | A bug fix                                             | `fix(api): handle null user in profile endpoint` |
| `docs`     | Documentation only                                    | `docs(readme): add deployment instructions`      |
| `refactor` | Code change with no behavior change                   | `refactor(db): extract query builder to module`  |
| `test`     | Adding or updating tests                              | `test(api): add rate limiting tests`             |
| `chore`    | Maintenance, tooling, config                          | `chore(deps): upgrade axios to 1.7.0`            |
| `style`    | Formatting, whitespace (no logic change)              | `style: format with prettier`                    |
| `perf`     | Performance improvement                               | `perf(api): cache user queries with Redis`       |
| `ci`       | CI/CD changes                                         | `ci: add test step to deploy workflow`           |
| `build`    | Build system or dependency changes                    | `build: migrate from webpack to vite`            |
| `revert`   | Revert a previous commit                              | `revert: feat(auth): add OAuth login flow`       |

## Breaking Changes

Add a `!` after the type/scope, or include `BREAKING CHANGE:` in the footer:

```
feat(api)!: migrate REST endpoints to GraphQL

BREAKING CHANGE: All /api/v1/* endpoints are removed.
Use GraphQL at /graphql instead.
```

## Good Examples

```
feat(cart): add quantity selector to cart items
fix(api): return 404 for deleted products instead of 500
refactor(auth): extract token validation to middleware
test(api): add pagination edge case tests
chore(deps): pin postgres image to 16-alpine
docs(api): document webhook payload format
perf(db): add index on orders.user_id
ci: add eslint to PR workflow
style: remove trailing whitespace
```

## Bad Examples

```
fixed stuff                  # Missing type, too vague
Update file                  # Missing type, no scope
asdf                        # Meaningless
WIP                         # Not a commit message
feat: stuff                  # Missing scope, vague description
fix(auth):                  # Empty description
FEAT(AUTH): ADD THING       # Wrong case — lowercase only
```

## Body and Footer

Use the body to explain *why* the change was made, not *what* changed:

```
feat(auth): add rate limiting to login endpoint

Login endpoints were vulnerable to brute force attacks.
This adds a token bucket rate limiter per IP address.

Closes #427
```

## Best Practices

- Keep the first line under 72 characters
- Use the body to explain the motivation, not the implementation
- Reference issues with `Closes #123`, `Fixes #456`, `Refs #789`
- One logical change per commit
- Use imperative mood: "add" not "added" or "adds"
- The commit message should complete the sentence: "This commit will..."
