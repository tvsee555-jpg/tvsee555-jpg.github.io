# AI Dev Config Pack

Stop explaining your project to AI every session. Drop in pre-built `.cursorrules`, `CLAUDE.md`, and MCP configs and your AI assistant instantly understands your stack.

## What's Included

### 5 Stack-Specific .cursorrules
| Stack | File | Key Rules |
|---|---|---|
| Next.js 14+ / TypeScript | `nextjs-typescript.cursorrules` | App Router, server components, Prisma, Shadcn UI |
| Python / FastAPI | `python-fastapi.cursorrules` | SQLAlchemy 2.0, Pydantic v2, async, Alembic |
| Go 1.22+ | `go-server.cursorrules` | chi router, sqlx, testing, Docker multi-stage |
| Rust / CLI | `rust-cli.cursorrules` | clap, anyhow, tokio, serde, thiserror |
| Node.js / Express | `node-express.cursorrules` | Zod validation, Prisma, Jest, middleware patterns |

Each file contains 40+ rules covering: naming conventions, project structure, error handling, testing patterns, security, performance, and common gotchas.

### CLAUDE.md Template
A complete project context file for Claude Code / Cursor with:
- Tech stack overview
- Project structure conventions  
- Branch naming and commit message style
- Common commands
- Environment variable templates

### MCP Server Configs
- `filesystem-mcp.json` — File system access for Claude
- `context7-mcp.json` — Library documentation lookup

### Installer
One-command setup that detects your stack and installs the right files:

```bash
bash install.sh
# or specify a target directory:
bash install.sh /path/to/your/project
```

## Quick Start

1. Copy the pack to your project:
   ```bash
   cp -r ai-dev-config-pack /path/to/your/project/
   cd /path/to/your/project/ai-dev-config-pack
   ```

2. Run the installer:
   ```bash
   bash install.sh
   ```

3. Edit `CLAUDE.md` with your project's actual details.

4. If using Cursor/Claude Code, your AI assistant will now understand your stack conventions — no more explaining your project structure every session.

## Requirements
- Any project using one of the supported stacks
- Cursor, Claude Code, or any AI coding tool that reads `.cursorrules` / `CLAUDE.md`

## Why Buy This?

Without these rules, AI assistants make generic suggestions that don't fit your stack. A Next.js app and a FastAPI backend get the same treatment. With stack-specific rules:

- AI generates idiomatic code for your framework
- Follows your project's naming and structure conventions
- Knows which libraries you use and which to avoid
- Produces production-quality patterns, not tutorial examples

## License
MIT — use in personal and commercial projects.
