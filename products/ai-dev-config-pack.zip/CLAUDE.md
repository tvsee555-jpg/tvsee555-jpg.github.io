# Project Overview

Replace this with your project name and a 1-2 sentence description of what it does.

## Tech Stack

- **Runtime**: [Node.js 20+ / Python 3.12+ / Go 1.22+ / Rust 1.78+]
- **Framework**: [Next.js 14+ / FastAPI / chi / clap]
- **Database**: [PostgreSQL 16 / SQLite / MySQL 8]
- **ORM**: [Prisma / SQLAlchemy 2.0 / sqlx / diesel]
- **Testing**: [Vitest+Playwright / pytest / Go testing+testify / rstest]
- **CI/CD**: GitHub Actions
- **Deployment**: [Vercel / Railway / Docker]

## Project Structure

```
src/
├── app/          # Next.js App Router pages
├── components/   # Shared React components
├── lib/          # Utility functions
├── db/           # Database schema and queries
└── types/        # Shared TypeScript types
```

## Conventions

### Branch Naming
- `feature/description` — New features
- `fix/description` — Bug fixes  
- `chore/description` — Maintenance
- `hotfix/description` — Urgent production fixes

### Commit Messages
Use conventional commits: `type(scope): description`
- `feat:` — New feature
- `fix:` — Bug fix
- `refactor:` — Code change with no behavior change
- `test:` — Adding or updating tests
- `docs:` — Documentation only
- `chore:` — Build/config changes

### Code Style
- TypeScript: strict mode, prefer interfaces over types
- Python: PEP 8, type hints everywhere
- Go: gofmt, errcheck, golangci-lint
- Rust: clippy, rustfmt

## Common Commands

```bash
# Development
npm run dev          # Start dev server
npm run build        # Type-check and build
npm run test         # Run tests
npm run lint         # Lint and format

# Database
npm run db:migrate   # Run migrations
npm run db:seed      # Seed test data
npm run db:studio    # Open Prisma Studio

# Docker
docker compose up    # Start all services
docker compose down  # Stop all services
```

## Environment Variables

Copy `.env.example` to `.env` and fill in required values:

```
DATABASE_URL=postgresql://user:pass@localhost:5432/db
REDIS_URL=redis://localhost:6379
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

## Deployment

- PRs to `main` auto-deploy via GitHub Actions
- Preview deployments for PR branches
- Production: manual approval required
