#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}╔══════════════════════════════════════╗${NC}"
echo -e "${BLUE}║   AI Dev Config Pack — Installer     ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════╝${NC}"
echo ""

# Detect project type
detect_stack() {
    local files=("$1"/*)
    local has_package_json=false
    local has_requirements=false
    local has_go_mod=false
    local has_cargo=false

    for f in "$1"/*; do
        case "$(basename "$f")" in
            package.json) has_package_json=true ;;
            requirements.txt|pyproject.toml|setup.py) has_requirements=true ;;
            go.mod) has_go_mod=true ;;
            Cargo.toml) has_cargo=true ;;
        esac
    done

    # Check for next.config in package.json projects
    if $has_package_json; then
        if grep -q '"next"' "$1/package.json" 2>/dev/null; then
            echo "nextjs"
            return
        fi
        echo "express"
        return
    fi
    if $has_go_mod; then echo "go"; return; fi
    if $has_cargo; then echo "rust"; return; fi
    if $has_requirements || $has_pyproject; then echo "fastapi"; return; fi

    echo "unknown"
}

TARGET_DIR="${1:-$(pwd)}"

if [ ! -d "$TARGET_DIR" ]; then
    echo -e "${RED}Error: Directory '$TARGET_DIR' does not exist${NC}"
    exit 1
fi

STACK=$(detect_stack "$TARGET_DIR")
echo -e "Detected stack: ${GREEN}$STACK${NC}"
echo ""

case "$STACK" in
    nextjs)
        RULES_FILE="$SCRIPT_DIR/nextjs-typescript.cursorrules"
        ;;
    express|node)
        RULES_FILE="$SCRIPT_DIR/node-express.cursorrules"
        ;;
    fastapi|python)
        RULES_FILE="$SCRIPT_DIR/python-fastapi.cursorrules"
        ;;
    go)
        RULES_FILE="$SCRIPT_DIR/go-server.cursorrules"
        ;;
    rust)
        RULES_FILE="$SCRIPT_DIR/rust-cli.cursorrules"
        ;;
    unknown)
        echo -e "${RED}Could not detect project stack.${NC}"
        echo "Available rules:"
        ls "$SCRIPT_DIR"/*.cursorrules 2>/dev/null | while read -r f; do
            echo "  $(basename "$f" .cursorrules)"
        done
        echo ""
        read -r -p "Enter stack name from list above: " STACK
        RULES_FILE="$SCRIPT_DIR/$STACK.cursorrules"
        if [ ! -f "$RULES_FILE" ]; then
            echo -e "${RED}Unknown stack: $STACK${NC}"
            exit 1
        fi
        ;;
esac

# Install .cursorrules
if [ -f "$RULES_FILE" ]; then
    cp "$RULES_FILE" "$TARGET_DIR/.cursorrules"
    echo -e "${GREEN}✓${NC} Installed .cursorrules for ${GREEN}$STACK${NC}"
else
    echo -e "${RED}✗${NC} Missing rules file for $STACK"
fi

# Install CLAUDE.md
CLAUDE_SRC="$SCRIPT_DIR/CLAUDE.md"
CLAUDE_DEST="$TARGET_DIR/CLAUDE.md"
if [ -f "$CLAUDE_SRC" ]; then
    if [ -f "$CLAUDE_DEST" ]; then
        cp "$CLAUDE_DEST" "$CLAUDE_DEST.bak"
        echo -e "  Backed up existing CLAUDE.md → ${GREEN}CLAUDE.md.bak${NC}"
    fi
    cp "$CLAUDE_SRC" "$CLAUDE_DEST"
    echo -e "${GREEN}✓${NC} Installed CLAUDE.md template (edit to match your project)"
fi

# Install MCP configs (opt-in)
MCP_DIR="$TARGET_DIR/.vscode"
if [ -d "$TARGET_DIR/.vscode" ] || mkdir -p "$MCP_DIR" 2>/dev/null; then
    mkdir -p "$MCP_DIR"
    if ls "$SCRIPT_DIR/mcp-configs/"*.json 1>/dev/null 2>&1; then
        echo ""
        echo "MCP server configs available in mcp-configs/:"
        for f in "$SCRIPT_DIR/mcp-configs/"*.json; do
            echo "  $(basename "$f")"
        done
        echo "Copy them to your project's .vscode/ or MCP config manually."
    fi
fi

echo ""
echo -e "${GREEN}✓ Setup complete!${NC}"
echo ""
echo "Next steps:"
echo "  1. Edit CLAUDE.md with your project details"
echo "  2. If using Cursor, AI will now follow your stack's conventions"
echo "  3. Commit the new files to version control"
echo ""
echo "To uninstall: rm .cursorrules CLAUDE.md"
